%%  robot_dyn.m
%%  Author:     YG Choi
%%  Date:       Apr 1 2005
%%  Description:  function for the 2 link robotic system dynamics

function xdot = robot_dyn_2dof(x, tau)
    
global m1
global m2 
global le1
global le2
%g = 9.8;
g = 0;

m11 = (m1+m2)*le1^2 + m2*le2^2 + 2*m2*le1*le2*cos(x(2));
m22 = m2*le2*le2;
m12 = m22 + m2*le1*le2*cos(x(2));

v1 = -m2*le1*le2*(2*x(3)*x(4)+x(4)*x(4))*sin(x(2));
v2 = m2*le1*le2*x(3)*x(3)*sin(x(2));

g1 = (m1+m2)*g*le1*cos(x(1)) + m2*g*le2*cos(x(1)+x(2));
g2 = m2*g*le2*cos(x(1)+x(2));

det = m11*m22 - m12^2;

a1 = tau(1) - v1 - g1;
a2 = tau(2) - v2 - g2;

xdot(1) = x(3);
xdot(2) = x(4);
xdot(3) = (m22*a1 - m12*a2)/det;
xdot(4) = (m11*a2 - m12*a1)/det;

return
