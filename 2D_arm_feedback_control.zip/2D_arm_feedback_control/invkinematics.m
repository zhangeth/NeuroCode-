function q = invkinematics(xPos)
% arm_param;
global le1
global le2

q = zeros(2,1);

% Exact inverse
q(2) = acos( ( sum(xPos.^2)-(le1^2+le2^2) ) / (2*le1*le2) );
q(1) = atan2(xPos(2), xPos(1)) - q(2)/2;

return

