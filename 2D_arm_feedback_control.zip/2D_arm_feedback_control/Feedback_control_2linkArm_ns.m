% BKN 618 feedback control of a 2D arm 03/07/2012
% instructor complete version
% to do
% understand the code
% add delays = very delays at 10, 30, and 50 msec - modify feedabck gains
% accordingly (to avoid major oscillations and keep ok performance) 
% compute forward kinematics
% plot x,y trajectory
% plot velocity profile (is it bell shaped?)
% generate 8 targets to generate "Georgopoulous-like" reaching movements (16 movements total)
close all
clear all

% Initialization
duration = 400;
max_time_index = 1000

transient_time = 500;  % for plotting(
deltaT = 0.001;

trial_max = 7;

xGoal = [0.0 0.0 0.0 0.2 0  -0.2 0 ;
         0.1 0.3 0.1 0.2 0.1 0.2 0.1];

% feedback gains
P = 20;  % position
D = 10; % velocity

xInit = [0.0;0.0];
xDes = [0.0;0.0];

qIntPre = 0;
qState = [-pi/4 pi 0 0 0 0];
qPreState = qState;

%arm parameter
global m1;
global m2;
global le1;
global le2;

m1 = 3.;
m2 = 3.;
le1 = 0.3;
le2 = 0.3;


t = 0;

%return

for trial = 1:trial_max

    time_des = 0;

    for time_index =1:max_time_index

        time_index;
        time_des = 1 + time_des;
        t = 0;

        % here the old final position is the new initial position
        
        if time_index == max_time_index
            xInit(1) = xDes(1);
            xInit(2) = xDes(2);
        end
        
        if  time_des <= duration

            t=0+deltaT*time_des;

            %%% xDes is the desired position trajectory.
            % minimum jerk
            xDes(1) = xInit(1) + (xGoal(1,trial)- xInit(1))*(10*(t/(duration*deltaT))^3 -15*(t/(duration*deltaT))^4 + 6*(t/(duration*deltaT))^5);
            xDes(2) = xInit(2) + (xGoal(2,trial)- xInit(2))*(10*(t/(duration*deltaT))^3 -15*(t/(duration*deltaT))^4 + 6*(t/(duration*deltaT))^5);

        end

        % Inverse kinematics
        if ((trial == 1) && (time_des == 1))
            qDesState = [-pi/4; pi];
            qDesPrev = qDesState;
        else
            qDesState = invkinematics(xDes);
        end

        %%% Desired state vector setting using desired trajectory

        qDesState(3) = (qDesState(1)-qDesPrev(1))/deltaT;
        qDesState(4) = (qDesState(2)-qDesPrev(2))/deltaT;

        qDesPrev(1) = qDesState(1);
        qDesPrev(2) = qDesState(2);

        %%% PD control for the convergence.
        tauS = P*(qDesState(1) - qState(1)) + D*(qDesState(3) - qState(3));
        tauE = P*(qDesState(2) - qState(2)) + D*(qDesState(4) - qState(4));

        tau = [tauS tauE];

        %%%%%%% Newton dynamics and numerical integration.
        qDot = robot_dyn_2dof(qState,tau);

        %%% Euler method
        qPreState = qState;
        qState(5:6) = qDot(3:4);
        qState(1:4) = qDot*deltaT + qState(1:4);

        %% forward kinematics
        x(1) = 0.3 * cos(qState(1)) + 0.3 * cos(qState(1) + qState(2));
        x(2) = 0.3 * sin(qState(1)) + 0.3 * sin(qState(1) + qState(2));

        %% Data store for plotting
        qDesPlot(((trial-1) *max_time_index) + time_index,:) = qDesState;
        qPlot(((trial -1) *max_time_index) +time_index,:) = qState;
        qPlotTorque(((trial - 1) *max_time_index) +time_index,:) = tau;
        
        xDesPlot(((trial -1) *max_time_index) +time_index,:) = xDes;
        xRealPlot(((trial -1) *max_time_index) +time_index,:) = x;
        
        tauEPlot(((trial -1) *max_time_index) +time_index,:) = tauE;
        tauSPlot(((trial -1) *max_time_index) +time_index,:) = tauS;


    end

end

total_time = (max_time_index*trial_max);

m=2;
n=2;
figure(1)
subplot(m,n,1)
plot(transient_time:total_time, qPlot(transient_time:total_time,1), 'k', transient_time:total_time, qDesPlot(transient_time:total_time,1))
title('Angle S')

subplot(m,n,2)
plot(transient_time:total_time, qPlot(transient_time:total_time,2),  'k',transient_time:total_time, qDesPlot(transient_time:total_time,2))
title('Angle E')
subplot(m,n,3)
plot(transient_time:total_time, qPlot(transient_time:total_time,3), 'k', transient_time:total_time, qDesPlot(transient_time:total_time,3))
title('Angular velocity S')
subplot(m,n,4)
plot(transient_time:total_time, qPlot(transient_time:total_time,4), 'k', transient_time:total_time, qDesPlot(transient_time:total_time,4))
title('Angular velocity E')

figure(2)
hold on

plot(xRealPlot(:,1), xRealPlot(:,2), 'k*', xDesPlot(:,1), xDesPlot(:,2), '.')

title('x-y trajectory')
axis('equal')

figure(3)
plot(transient_time:total_time, tauSPlot(transient_time:total_time), 'k', transient_time:total_time, tauEPlot(transient_time:end))
title('torques (Nm)')
legend('Torque S', 'Torque E')

